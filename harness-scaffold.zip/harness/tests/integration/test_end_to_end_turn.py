# tests/integration/test_end_to_end_turn.py
#
# RESPONSIBILITY
#   Full async turn through a real Harness. No mocks beyond recording sink.
#
# WHAT TO TEST
#   All tests are async (pytest-asyncio, mode=auto).
#
#   - Happy path (top-level agent):
#       load_sources → scan_input allow → check_tool_call allow →
#       scan_output allow → unload_sources.
#       Exactly THREE AuditEvents in order: input_scan, tool_call_gate,
#       output_scan. Each carries agent_id, sub_agent_id=None.
#
#   - Input PII blocking: SSN-like text → scan_input blocked.
#
#   - Tool deny by allowed_tool_names (L1b):
#       research_agent tries "send_email" → deny "tool not in agent tool list"
#       BEFORE policy eval. AuditEvent decision="deny".
#
#   - Tool deny by policy:
#       orchestrator_agent, send_email, policy deny rule fires.
#
#   - Subagent turn:
#       scope_context_for_subagent(ctx, "research_sub") → child_ctx
#       child_ctx.agent_id == ctx.agent_id (parent preserved)
#       child_ctx.sub_agent_id == "research_sub"
#       load_sources(child_ctx) → only research_sub's sources active
#       check_tool_call("search_docs", ..., child_ctx) → allow
#       check_tool_call("send_email", ..., child_ctx) → deny (not in sub allowlist)
#       AuditEvents carry sub_agent_id="research_sub"
#
#   - Subagent isolation:
#       Parent's ScopedRegistryView ≠ child's ScopedRegistryView.
#       Tools loaded for child invisible to parent's check_tool_call.
#
#   - unload_sources clears view:
#       After unload_sources(child_ctx), _views key absent.
#
# DO NOT
#   - Hit the network. No production adapters here.
#   - Mock reference adapters.
