# tests/contracts/scanner_contract.py — Scanner conformance suite.
#
# WHAT TO IMPLEMENT
#   class ScannerContract:
#       scanner_factory: ClassVar[Callable[[], Scanner]]
#
#       async def test_returns_scanresult_shape(self): ...
#       async def test_findings_have_required_fields(self): ...
#       async def test_name_is_stable(self): ...
#       async def test_pure_for_same_input(self): ...
#       async def test_does_not_raise_on_arbitrary_text(self): ...
#       async def test_no_raw_match_in_finding_detail(self): ...
#
#       async def test_concurrent_scan(self):
#           """20 concurrent async scan() calls. No exceptions."""
#           scanner = self.scanner_factory()
#           results = await asyncio.gather(
#               *[scanner.scan("test input", make_ctx()) for _ in range(20)],
#               return_exceptions=True
#           )
#           assert not any(isinstance(r, Exception) for r in results)
