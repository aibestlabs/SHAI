# Agent registry and profiles

PLACEHOLDER FOR THE CODING AGENT.

## What goes here

Sections:

1. **agent-xx.yaml schema** — field-by-field documentation of AgentConfig
   and SubAgentConfig. Every field, its type, its default, its purpose.

2. **Agent identity model** — `agent_id` is mandatory and always identifies
   the top-level agent. `sub_agent_id` is optional; when set, this is a
   subagent and its parent is `agent_id`. No third field. `user_id` and
   `session_id` are audit-only fields — the harness never uses them for
   any internal decision.

3. **One parent → many subagents. One subagent → one parent.**
   Subagents declared inside parent's agent-xx.yaml. Subagent id unique
   within parent. Two different parents may each declare a "research_sub".
   Effective identity is always the pair (agent_id, sub_agent_id).

4. **The four-layer evaluation model** — L1a (registered?), L1b
   (allowed_tool_names?), L1c (allowed_tags?), L2 (intersection policy).
   Show the evaluation flowchart.

5. **Principle of least privilege** — every agent and subagent declares
   only the tools it needs (allowed_tool_names as hard gate) and only the
   capability envelope it needs (allowed_tags). Subagent allowed_tool_names
   and allowed_tags must be ⊆ parent's. Validated at load_agent() time.

6. **Subagent sources are independent** — not required to be ⊆ parent's
   sources. Each declares only what it needs. allowed_tags is the
   enforcement mechanism.

7. **Intersection policy model** — global ∩ parent ∩ subagent rules.
   First deny wins. Restriction flows downward only. No re-declaration.

8. **Registry lifecycle** — load, reload, deregister, list via facade and
   CLI. Atomicity guarantee on reload. Concurrent get() safety.

9. **Per-agent isolation** — own RuntimeContext, own ScopedRegistryView
   (keyed on (agent_id, sub_agent_id or "")), own audit trail, own profile,
   own log_level. Structural, not configurable.

10. **scope_context_for_subagent** — called by framework integrations at
    the subagent handoff point, not by agent code. Returns RuntimeContext
    with agent_id preserved (parent), sub_agent_id set, allowed_tags from
    SubAgentConfig. Sync pure function.

## What does NOT go here

- Policy rule grammar (docs/policy.md).
- Source activation (docs/sources.md).
- Adapter writing (docs/adapters.md).
