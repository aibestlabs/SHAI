# harness/agents/registry.py — the AgentRegistry.
#
# RESPONSIBILITY
#   Runtime-managed in-memory registry of AgentConfig instances.
#   Operator-driven — no file watching, no automatic reload.
#   All public methods are async for consistency with the facade.
#   Internal: threading.Lock protects writes; reads are GIL-safe.
#
# WHAT TO IMPLEMENT
#   - AgentRegistry class:
#       Internal state: dict[str, AgentConfig]  (agent_id → config)
#       Write lock: threading.Lock
#
#       async load(path) -> AgentConfig:
#           1. Read and yaml.safe_load. IOError/YAMLError → ConfigError.
#           2. Validate against AgentConfig schema. ValidationError →
#              ConfigError. This also validates subagent constraints
#              (allowed_tool_names ⊆ parent, allowed_tags ⊆ parent).
#           3. Identical content already registered: no-op, return existing.
#           4. Different content for same id: raise AgentConflictError.
#           5. New id: acquire lock, store, release.
#
#       async reload(path) -> AgentConfig:
#           1. Validate (steps 1-2 above).
#           2. id not in registry: raise AgentNotRegisteredError.
#           3. Acquire lock, swap atomically, release.
#           In-flight calls complete against their RuntimeContext snapshot.
#           Invalid file: raise ConfigError, keep old definition.
#
#       async deregister(agent_id) -> None:
#           Acquire lock, remove, release.
#           Raises AgentNotRegisteredError if not found.
#
#       get(agent_id) -> AgentConfig:  [SYNC — hot path]
#           Called on every check_tool_call. Lock-free read.
#           Raises AgentNotRegisteredError on miss.
#           Must be sync so scope_context_for_subagent stays sync.
#
#       async list() -> list[AgentConfig]:
#           Return all registered in registration order.
#
# CONCURRENCY
#   get() is on the hot path. Lock-free dict read in CPython (GIL).
#   load/reload/deregister acquire the write lock.
#   scope_context_for_subagent calls get() synchronously — this is
#   intentional and safe.
#
# DO NOT
#   - Watch files or trigger automatic reloads.
#   - Persist state to disk.
#   - Add TTLs or soft-deletes.
#   - Make get() async — scope_context_for_subagent must be sync.
