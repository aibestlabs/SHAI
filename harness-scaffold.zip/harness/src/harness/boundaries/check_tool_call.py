# harness/boundaries/check_tool_call.py — the tool-call gate.
#
# RESPONSIBILITY
#   Mandatory boundary. Four-layer async evaluation. Emit exactly one
#   audit event. Return GateDecision. Never dispatch the tool.
#
# WHAT TO IMPLEMENT
#   async def run(
#       name: str,
#       args: dict[str, Any],
#       ctx: RuntimeContext,
#       *,
#       agent_registry: AgentRegistry,
#       registry_view: ToolRegistry | ScopedRegistryView,
#       policy: PolicyEngine,
#       arg_scanners: list[Scanner],
#       emitter: AuditEmitter,
#       scan_args_for_tags: set[str] = frozenset({"sensitive"}),
#   ) -> GateDecision
#
#   Algorithm — four layers, strict order:
#
#   LAYER 1a — Agent/subagent registered?
#     agent = agent_registry.get(ctx.agent_id)   [sync — see registry.py]
#     AgentNotRegisteredError → deny "agent not registered", emit, return.
#
#     If ctx.sub_agent_id is set:
#       sub = agent.get_sub_agent(ctx.sub_agent_id)
#       SubAgentNotDeclaredError → deny "subagent not declared", emit, return.
#       effective_profile = sub
#     Else:
#       effective_profile = agent
#
#   LAYER 1b — Tool lookup + allowed_tool_names gate
#     tool = await registry_view.get(name)
#     ToolNotRegisteredError → deny "unknown tool: <name>", emit, return.
#
#     If name not in effective_profile.allowed_tool_names:
#       deny "tool not in agent tool list", emit, return.
#     (Principle of least privilege — hard gate before any policy eval.)
#
#   LAYER 1c — allowed_tags capability gate
#     If ctx.allowed_tags set and not tool.tags ⊆ ctx.allowed_tags:
#       deny "tool not in agent capability set", emit, return.
#
#   LAYER 2 — Intersection policy evaluation
#     Build rule set:
#       if sub_agent_id set: rules = sub.policy_rules + agent.policy_rules
#       else: rules = agent.policy_rules
#     decision = await policy.evaluate(tool, args, ctx, rules=rules)
#     Global rules evaluated inside policy.evaluate after the provided
#     rules (intersection model — first deny anywhere wins).
#     PolicyEvaluationError → emit failure event, re-raise.
#
#   LAYER 3 — Optional arg scanning
#     If decision allow/redact AND tool.tags ∩ scan_args_for_tags:
#       Run arg_scanners concurrently (asyncio.gather).
#       Any finding.severity >= high → deny "args scan blocked: <category>".
#
#   AUDIT + RETURN
#     Build AuditEvent with agent_id, sub_agent_id, tool_name, transport,
#     adapters, decision, duration_ms. Populate audit_tags from
#     effective_profile.audit_tags.
#     await emitter.emit(event).
#     Return GateDecision.
#
# INVARIANTS
#   - Exactly one AuditEvent per call, every path.
#   - Never dispatches the tool.
#   - No enabled flag — mandatory.
#   - When allowed=False, deny_reason is always non-empty.
#   - Layer order is fixed. No config option changes it.
#   - agent_registry.get() is sync — intentional. See registry.py.
#   - Arg scanners run concurrently via asyncio.gather.
#
# DO NOT
#   - Cache decisions.
#   - Mutate args in place.
#   - Add transport-specific branching. Tags + policy handle that.
#   - Key on user_id or session_id.
