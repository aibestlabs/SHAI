# harness/audit/sink.py — the AuditSink Protocol.
#
# RESPONSIBILITY
#   Define the single Protocol every audit sink implements. All async.
#
# WHAT TO IMPLEMENT
#   - AuditSink as a typing.Protocol:
#
#       name: str
#
#       async def emit(self, event: AuditEvent) -> None:
#           """Ship one event. Best-effort. A sink failure must not break
#           the boundary call. The AuditEmitter logs failures and continues.
#           Sinks needing batching or retry handle it internally.
#           Must be safe for concurrent async calls from multiple agents.
#           """
#
#       async def close(self) -> None:
#           """Flush and release resources. Default no-op for stateless sinks."""
#
# DO NOT
#   - Add sync emit() variant.
#   - Make emit() return a status.
#   - Add filtering or transformation.
