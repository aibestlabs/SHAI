# harness/core/events.py — the AuditEvent schema.
#
# RESPONSIBILITY
#   The structured event every boundary emits exactly once per call.
#   Consumed by every AuditSink. See docs/audit-schema.md.
#
# WHAT TO IMPLEMENT
#   - AuditEvent as a frozen pydantic model (canonical field names —
#     must match CLAUDE.md §6 logging fields exactly):
#
#     IDENTITY (from RuntimeContext):
#       tenant_id:      str
#       agent_id:       str
#       sub_agent_id:   str | None
#       user_id:        str | None   (audit trail correlation only)
#       session_id:     str | None   (audit trail correlation only)
#
#     BOUNDARY:
#       timestamp:      datetime     (UTC)
#       boundary:       BoundaryName (input_scan | tool_call_gate | output_scan)
#       decision:       Decision     (allow | deny | redact | blocked)
#       disabled:       bool         (true when boundary disabled by config)
#       duration_ms:    int
#
#     TOOL CALL (tool_call_gate only):
#       tool_name:      str | None
#       transport:      str | None
#
#     SCAN RESULTS:
#       adapters:       list[str]    (adapter names that ran)
#       finding_count:  int
#       max_severity:   Severity | None
#       deny_reason:    str | None
#
#     AGENT CONTEXT:
#       audit_tags:     dict[str, str]  (from AgentConfig.audit_tags)
#       extra:          dict[str, Any]  (small adapter-specific context)
#
#   Cross-field constraints (model validators):
#     - decision="deny" → deny_reason non-empty, boundary="tool_call_gate"
#     - decision="blocked" → boundary is a scan boundary
#     - disabled=True → decision="allow", finding_count=0
#     - tool_name and transport populated only for tool_call_gate
#
#   - AuditEvent.build(...) — canonical builder. Boundaries never
#     construct AuditEvent by hand.
#
# DO NOT
#   - Include raw user input, LLM output, tool args, or scanner matches.
#   - Add source_names — load_sources does not emit.
#   - Add sink-specific fields (Splunk index, OTel trace id).
#   - Use user_id or session_id for any decision — they are audit-only.
#   - Make AuditEvent mutable.
