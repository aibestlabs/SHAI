# harness/core/types.py — shared enums and type aliases.
#
# RESPONSIBILITY
#   Stable enums used across modules. Bottom of the import graph —
#   imports nothing from harness.*.
#
# WHAT TO IMPLEMENT
#   - BoundaryName: StrEnum
#       "input_scan" | "tool_call_gate" | "output_scan"
#
#   - Decision: StrEnum
#       "allow" | "deny" | "redact" | "blocked"
#
#   - Severity: StrEnum
#       "info" | "low" | "medium" | "high" | "critical"
#
#   - Transport: StrEnum
#       "local" | "mcp" | "skill"
#
# DO NOT
#   - Add "sandbox" transport — removed. Use tool tags instead.
#   - Add behavior. Enums only.
#   - Invent variant casings — logging fields must match exactly.
