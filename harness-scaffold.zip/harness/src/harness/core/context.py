# harness/core/context.py — RuntimeContext, the identity envelope.
#
# RESPONSIBILITY
#   Carry the identity of every boundary call. Two kinds of fields:
#   - Agent identity fields: used by the harness internally for keying,
#     policy evaluation, and source activation.
#   - Audit fields: carried for logging and audit trail correlation only;
#     the harness never uses them as keys or in policy.
#
# WHAT TO IMPLEMENT
#   - RuntimeContext as a frozen pydantic model:
#
#     AGENT IDENTITY FIELDS (used internally by harness):
#       tenant_id:    str        (required, non-empty)
#       agent_id:     str        (required, non-empty — always the top-level agent)
#       sub_agent_id: str | None (set only for subagent calls;
#                                 if set, parent is agent_id)
#
#     AUDIT FIELDS ONLY (never used as keys, never in policy, never in
#     source activation, never in view keying):
#       user_id:    str | None   (who triggered the call — for audit trail)
#       session_id: str | None   (session correlation — for audit trail)
#
#   - to_log_fields() -> dict:
#       Returns canonical logging dict using exact field names from
#       CLAUDE.md §6. Every logger in the codebase calls this — never
#       hand-build the dict elsewhere.
#       Returns: {tenant_id, agent_id, sub_agent_id, user_id, session_id}
#
#   - agent_key() -> tuple[str, str]:
#       Returns (agent_id, sub_agent_id or "") — the canonical key used
#       for ScopedRegistryView storage. This is the ONLY key the harness
#       uses internally. Called by load_sources and unload_sources.
#
# DO NOT
#   - Add request_id — removed. Not needed.
#   - Add parent_agent_id — removed. Parent is always agent_id when
#     sub_agent_id is set. No third field.
#   - Use user_id or session_id for any internal harness decision.
#     They are audit-only. Code that keys on user_id or session_id
#     internally is a bug.
#   - Make RuntimeContext mutable.
#   - Add memory, prompt, or LLM-related fields.
