# harness/adapters/scanners/base.py — the Scanner Protocol.
#
# RESPONSIBILITY
#   Define the single Protocol every text scanner implements. All async.
#
# WHAT TO IMPLEMENT
#   - ScanResult (internal, not public):
#       findings:       list[Finding]
#       redacted_text:  str | None
#
#   - Scanner as a typing.Protocol:
#       name: str
#
#       async def scan(
#           self,
#           text: str,
#           ctx: RuntimeContext,
#       ) -> ScanResult:
#           """Inspect text. Return findings and optional redacted form.
#           Pure: no side effects, no audit emission. Async because
#           production scanners (Purview, Nightfall, Lakera) are
#           network-bound. Reference scanners (regex) return immediately.
#           """
#
# DO NOT
#   - Add severity_threshold parameter — boundaries control blocking.
#   - Add sync scan() variant.
#   - Add per-scanner config to the Protocol.
