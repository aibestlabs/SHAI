# harness/adapters/audit_sinks/file.py — async rotating file sink.
#
# RESPONSIBILITY
#   Write one JSON object per line to a rotating file on disk. Async
#   wrapper around synchronous file I/O via asyncio executor.
#
# WHAT TO IMPLEMENT
#   - FileSink implementing AuditSink:
#       name = "file"
#       Constructor: path, max_bytes=100_000_000, backup_count=10,
#                    encoding="utf-8"
#       Internal: asyncio.Lock (not threading.Lock — we are async)
#                 RotatingFileHandler or hand-written rotator
#
#       async emit(event):
#           async with self._lock:
#               await loop.run_in_executor(None, self._write, event)
#
#       async close():
#           async with self._lock:
#               await loop.run_in_executor(None, self._file.close)
#
#   asyncio.Lock serialises concurrent async emit() calls.
#   run_in_executor offloads the blocking write to a thread pool.
#
# ENTRY POINT: harness.audit_sinks / "file"
