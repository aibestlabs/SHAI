# harness/adapters/audit_sinks/stdout.py — async JSONL stdout sink.
#
# RESPONSIBILITY
#   Emit one JSON object per line to stdout. Async wrapper around
#   synchronous write — acceptable since stdout writes are fast and
#   this sink is development/container use only.
#
# WHAT TO IMPLEMENT
#   - StdoutSink implementing AuditSink:
#       name = "stdout"
#       Constructor: optional stream (default sys.stdout).
#
#       async emit(event):
#           Serialize event to JSON (one line).
#           asyncio.get_event_loop().run_in_executor(None, write_and_flush)
#           OR just call write/flush synchronously — stdout writes are
#           fast enough that blocking the event loop briefly is acceptable
#           for a dev-only sink. Document the choice.
#
#       async close(): no-op.
#
#   Thread/async safety note: in CPython, sys.stdout.write() is GIL-safe
#   for individual calls. For async concurrent calls, writes may
#   interleave at the OS level. Acceptable for development; not suitable
#   as the sole production sink. Document this limit.
#
# ENTRY POINT: harness.audit_sinks / "stdout"
